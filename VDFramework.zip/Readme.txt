//
Hướng dẫn tích hợp thư viện:
Với Swift:

1. Tại file bridge header:
	#import <VDFramework/VDConfigNotification.h> 
2. Appdelegate
import VDFramework 